// Custom prompt window (slot 6)

const CustomPromptWindow = ({ clipboard, onSubmit, onClose }) => {
  const [text, setText] = React.useState("");
  const taRef = React.useRef(null);
  React.useEffect(() => { taRef.current && taRef.current.focus(); }, []);

  const presets = [
    "translate to formal Spanish",
    "make this sound more diplomatic",
    "explain like I'm five",
    "summarize in one sentence",
    "convert to bullet points",
  ];

  const onKey = (e) => {
    if (e.key === "Escape") { e.preventDefault(); onClose(); }
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      if (text.trim()) onSubmit(text.trim());
    }
  };

  return (
    <WindowFrame title="Custom prompt" subtitle="clipt9n · slot 6" width={520} onClose={onClose} accentDot>
      <div style={cp.label}>Instruction</div>
      <textarea
        ref={taRef}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={onKey}
        placeholder='e.g. "translate to formal Spanish"'
        style={cp.textarea}
        rows={3}
      />
      <div style={cp.presets}>
        {presets.map((p) => (
          <button key={p} onClick={() => setText(p)} style={cp.preset}>{p}</button>
        ))}
      </div>

      <div style={cp.previewLabel}>Will be applied to</div>
      <div style={cp.preview}>{clipboard.text.length > 200 ? clipboard.text.slice(0, 200) + "…" : clipboard.text}</div>

      <div style={cp.footer}>
        <span style={cp.hint}><kbd style={cp.kbd}>⌘</kbd>+<kbd style={cp.kbd}>↵</kbd> run · <kbd style={cp.kbd}>Esc</kbd> cancel</span>
        <button
          onClick={() => text.trim() && onSubmit(text.trim())}
          disabled={!text.trim()}
          style={{ ...cp.run, ...(text.trim() ? null : cp.runDisabled) }}>
          Run →
        </button>
      </div>
    </WindowFrame>
  );
};

const cp = {
  label: { fontSize: 11, color: "var(--ink-3)", textTransform: "uppercase", letterSpacing: 0.8, fontWeight: 600, marginBottom: 6 },
  textarea: {
    width: "100%", background: "var(--panel-2)", color: "var(--ink)",
    border: "1px solid var(--line)", borderRadius: 6,
    padding: "10px 12px", fontFamily: "var(--mono)", fontSize: 13,
    resize: "vertical", outline: "none",
  },
  presets: { display: "flex", flexWrap: "wrap", gap: 5, marginTop: 8 },
  preset: {
    background: "var(--panel-3)", color: "var(--ink-2)",
    border: "1px solid var(--line)", borderRadius: 999,
    padding: "3px 9px", fontSize: 11, fontFamily: "var(--mono)", cursor: "pointer",
  },
  previewLabel: { fontSize: 11, color: "var(--ink-3)", textTransform: "uppercase", letterSpacing: 0.8, fontWeight: 600, marginTop: 14, marginBottom: 6 },
  preview: {
    background: "var(--panel-2)", border: "1px solid var(--line-soft)",
    borderRadius: 6, padding: "8px 10px",
    fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-2)",
    maxHeight: 70, overflow: "hidden",
  },
  footer: {
    marginTop: 12, display: "flex", justifyContent: "space-between", alignItems: "center",
  },
  hint: { fontSize: 11, color: "var(--ink-3)", fontFamily: "var(--mono)" },
  kbd: { background: "var(--panel-3)", border: "1px solid var(--line)", padding: "1px 5px", borderRadius: 3, fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-2)", margin: "0 2px" },
  run: {
    background: "var(--accent)", color: "var(--accent-ink)",
    border: 0, borderRadius: 6, padding: "7px 14px",
    fontWeight: 600, fontSize: 12.5, cursor: "pointer", fontFamily: "inherit",
  },
  runDisabled: { background: "var(--panel-3)", color: "var(--ink-3)", cursor: "not-allowed" },
};

Object.assign(window, { CustomPromptWindow });
