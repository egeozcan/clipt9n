// "Open glossary" — TOML editor (faux-textmate look)

const GlossaryWindow = ({ contents, onClose, onSave, onReload }) => {
  const [text, setText] = React.useState(contents);
  const [dirty, setDirty] = React.useState(false);

  const lines = text.split("\n");

  const renderLine = (l) => {
    // crude TOML highlighter
    const parts = [];
    if (/^\s*#/.test(l)) return [{ t: l, c: "var(--ink-3)" }];
    const m = l.match(/^(\s*)(\[\[?[^\]]+\]\]?)(.*)$/);
    if (m) {
      parts.push({ t: m[1], c: "inherit" });
      parts.push({ t: m[2], c: "#ffb84d" });
      parts.push({ t: m[3], c: "var(--ink-3)" });
      return parts;
    }
    const kv = l.match(/^(\s*)([\w_]+)(\s*=\s*)(.*)$/);
    if (kv) {
      parts.push({ t: kv[1], c: "inherit" });
      parts.push({ t: kv[2], c: "#9ad6ff" });
      parts.push({ t: kv[3], c: "var(--ink-3)" });
      const val = kv[4];
      // strings vs comment
      const cm = val.match(/^(.*?)(\s*#.*)$/);
      if (cm) {
        parts.push({ t: cm[1], c: /^"/.test(cm[1]) ? "var(--accent)" : "var(--ink)" });
        parts.push({ t: cm[2], c: "var(--ink-3)" });
      } else {
        parts.push({ t: val, c: /^"/.test(val) || /^\[/.test(val) ? "var(--accent)" : "var(--ink)" });
      }
      return parts;
    }
    return [{ t: l, c: "inherit" }];
  };

  return (
    <WindowFrame title="glossary.toml" subtitle="~/Library/Application Support/clipt9n" width={680} onClose={onClose} accentDot plain>
      <div style={gw.toolbar}>
        <span style={gw.path}>file:///Users/you/Library/Application Support/clipt9n/glossary.toml</span>
        <span style={gw.spacer} />
        {dirty && <span style={gw.dirty}>● unsaved</span>}
        <button onClick={() => { onReload(); setText(contents); setDirty(false); }} style={gw.toolBtn}>reload</button>
        <button onClick={() => { onSave(text); setDirty(false); }} style={{ ...gw.toolBtn, ...gw.toolBtnPrimary }}>save</button>
      </div>
      <div style={gw.editor}>
        <div style={gw.gutter}>
          {lines.map((_, i) => <div key={i} style={gw.gutterLine}>{i + 1}</div>)}
        </div>
        <div style={gw.codeWrap}>
          <pre style={gw.code}>
            {lines.map((l, i) => (
              <div key={i} style={gw.codeLine}>
                {renderLine(l).map((p, j) => (
                  <span key={j} style={{ color: p.c }}>{p.t || "\u00A0"}</span>
                ))}
              </div>
            ))}
          </pre>
          <textarea
            value={text}
            onChange={(e) => { setText(e.target.value); setDirty(true); }}
            style={gw.textarea}
            spellCheck={false}
          />
        </div>
      </div>
      <div style={gw.statusbar}>
        <span>TOML</span>
        <span>·</span>
        <span>UTF-8</span>
        <span>·</span>
        <span>{lines.length} lines</span>
        <span style={gw.spacer} />
        <span>matching: <span style={{ color: "var(--accent)" }}>auto</span></span>
        <span>·</span>
        <span>{(text.match(/\[\[entry\]\]/g) || []).length} entries</span>
      </div>
    </WindowFrame>
  );
};

const gw = {
  toolbar: {
    display: "flex", alignItems: "center", gap: 8,
    padding: "8px 14px", borderBottom: "1px solid var(--line-soft)",
    background: "var(--panel-2)", fontSize: 11, fontFamily: "var(--mono)", color: "var(--ink-3)",
  },
  path: { whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 380 },
  spacer: { flex: 1 },
  dirty: { color: "var(--warn)" },
  toolBtn: { background: "var(--panel-3)", color: "var(--ink-2)", border: "1px solid var(--line)", borderRadius: 4, padding: "3px 9px", fontSize: 11, fontFamily: "var(--mono)", cursor: "pointer" },
  toolBtnPrimary: { background: "var(--accent)", color: "var(--accent-ink)", borderColor: "transparent", fontWeight: 600 },

  editor: { display: "grid", gridTemplateColumns: "44px 1fr", maxHeight: 380, minHeight: 280, overflow: "hidden", background: "#0e1014" },
  gutter: { padding: "10px 0", textAlign: "right", color: "var(--muted)", fontFamily: "var(--mono)", fontSize: 11.5, background: "var(--panel-2)", borderRight: "1px solid var(--line-soft)", userSelect: "none" },
  gutterLine: { padding: "0 8px", lineHeight: "20px" },
  codeWrap: { position: "relative", overflow: "auto" },
  code: {
    margin: 0, padding: "10px 12px",
    fontFamily: "var(--mono)", fontSize: 12.5, lineHeight: "20px",
    color: "var(--ink)", whiteSpace: "pre-wrap", wordBreak: "break-word",
  },
  codeLine: { minHeight: 20 },
  textarea: {
    position: "absolute", inset: 0, width: "100%", height: "100%",
    background: "transparent", color: "transparent", caretColor: "var(--accent)",
    border: 0, outline: 0, resize: "none",
    padding: "10px 12px",
    fontFamily: "var(--mono)", fontSize: 12.5, lineHeight: "20px",
  },
  statusbar: {
    display: "flex", alignItems: "center", gap: 6,
    padding: "5px 14px", borderTop: "1px solid var(--line-soft)",
    background: "var(--panel-2)", fontSize: 10.5, fontFamily: "var(--mono)", color: "var(--ink-3)",
  },
};

Object.assign(window, { GlossaryWindow });
