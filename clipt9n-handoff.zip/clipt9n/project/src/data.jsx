// Sample data + constants

const SAMPLES = [
  {
    id: "de_greeting",
    label: "DE greeting",
    text: "Guten Tag, wie geht es Ihnen heute? Ich hoffe, Sie hatten eine angenehme Reise.",
    detected: "de",
  },
  {
    id: "en_typo",
    label: "EN with typos",
    text: "He dont know that the api need to be updated before friday, otherwise their going to miss the deadlne.",
    detected: "en",
  },
  {
    id: "en_runon",
    label: "EN run-on",
    text: "So basically what I'm trying to say is that we should probably consider maybe rethinking the whole onboarding flow because users are getting confused at the second step and a lot of them just drop off and never come back which is obviously bad for retention.",
    detected: "en",
  },
  {
    id: "tr_short",
    label: "TR formal",
    text: "Lütfen raporu en kısa sürede gözden geçirir misiniz? Toplantı yarın saat 14:00'te başlayacak.",
    detected: "tr",
  },
  {
    id: "empty",
    label: "(empty clipboard)",
    text: "",
    detected: null,
  },
];

const SLOTS = [
  { n: 1, kind: "lang", label: "English", code: "en" },
  { n: 2, kind: "lang", label: "Deutsch", code: "de" },
  { n: 3, kind: "lang", label: "Türkçe", code: "tr" },
  { n: 4, kind: "fix",  label: "Fix grammar" },
  { n: 5, kind: "rewrite", label: "Rewrite for clarity" },
  { n: 6, kind: "custom",  label: "Custom prompt…" },
];

// Hand-authored, deterministic "model" outputs so the prototype feels real
// without making network calls.
const FAKE_RESULTS = {
  "de_greeting>en": "Good day, how are you today? I hope you had a pleasant journey.",
  "de_greeting>de": "Guten Tag, wie geht es Ihnen heute? Ich hoffe, Sie hatten eine angenehme Reise.",
  "de_greeting>tr": "İyi günler, bugün nasılsınız? Umarım keyifli bir yolculuk geçirmişsinizdir.",
  "en_typo>en":     "He doesn't know that the API needs to be updated before Friday, otherwise they're going to miss the deadline.",
  "en_typo>de":     "Er weiß nicht, dass die API vor Freitag aktualisiert werden muss, sonst verpassen sie die Frist.",
  "en_typo>tr":     "API'nin cumadan önce güncellenmesi gerektiğini bilmiyor, yoksa son tarihi kaçıracaklar.",
  "en_runon>en":    "We should rethink the onboarding flow. Users get confused at the second step and many drop off — that's hurting retention.",
  "en_runon>de":    "Wir sollten den Onboarding-Ablauf überdenken. Nutzer sind im zweiten Schritt verwirrt, und viele steigen aus — das schadet der Retention.",
  "en_runon>tr":    "Onboarding akışını yeniden düşünmeliyiz. Kullanıcılar ikinci adımda kafa karıştırıyor ve birçoğu vazgeçiyor — bu retention'ı düşürüyor.",
  "tr_short>en":    "Could you review the report as soon as possible? The meeting will start tomorrow at 2:00 PM.",
  "tr_short>de":    "Könnten Sie den Bericht so bald wie möglich durchsehen? Das Meeting beginnt morgen um 14:00 Uhr.",
  "tr_short>tr":    "Lütfen raporu en kısa sürede gözden geçirir misiniz? Toplantı yarın saat 14:00'te başlayacak.",
  // fix grammar -> stay in source language
  "en_typo>fix":    "He doesn't know that the API needs to be updated before Friday, otherwise they're going to miss the deadline.",
  "en_runon>fix":   "So basically what I'm trying to say is that we should probably consider maybe rethinking the whole onboarding flow, because users are getting confused at the second step and a lot of them just drop off and never come back, which is obviously bad for retention.",
  "de_greeting>fix":"Guten Tag, wie geht es Ihnen heute? Ich hoffe, Sie hatten eine angenehme Reise.",
  "tr_short>fix":   "Lütfen raporu en kısa sürede gözden geçirir misiniz? Toplantı yarın saat 14:00'te başlayacak.",
  // rewrite -> stay in source language
  "en_typo>rewrite":"He doesn't know the API needs updating before Friday — otherwise they'll miss the deadline.",
  "en_runon>rewrite":"We should rethink onboarding. Users get confused at step two and many drop off, which is hurting retention.",
  "de_greeting>rewrite":"Guten Tag — ich hoffe, Sie hatten eine angenehme Reise. Wie geht es Ihnen?",
  "tr_short>rewrite":"Raporu en kısa sürede gözden geçirebilir misiniz? Toplantı yarın 14:00'te.",
  // custom (default sample answer)
  "de_greeting>custom":"Sehr geehrte Damen und Herren, ich hoffe, Ihre Reise war angenehm. Bitte lassen Sie mich wissen, wie es Ihnen geht.",
  "en_typo>custom": "He is unaware that the API requires updating prior to Friday; failure to do so will result in a missed deadline.",
  "en_runon>custom":"Recommendation: Rethink the onboarding flow. Users are confused at step two, and a meaningful share drop off — a clear retention risk.",
  "tr_short>custom":"Sayın yetkili, raporu en kısa sürede gözden geçirmenizi rica ederim. Toplantı yarın saat 14:00'te başlayacaktır.",
};

// Initial seeded history (relative time strings; prototype doesn't compute real ages)
const SEED_HISTORY = [
  { id: 1001, ago: "2 min ago",  action: "translate", pair: "DE → EN", source: "Guten Tag, wie geht es Ihnen heute? Ich hoffe, Sie hatten eine angenehme Reise.", result: "Good day, how are you today? I hope you had a pleasant journey." },
  { id: 1002, ago: "14 min ago", action: "rewrite",   pair: "rewrite", source: "The api need to be updated before friday or else we miss the deadline and the customer is going to be upset about it.", result: "The API needs to be updated before Friday — otherwise we'll miss the deadline and the customer will be upset." },
  { id: 1003, ago: "32 min ago", action: "fix_grammar", pair: "grammar", source: "He dont know that the api need to be updated.", result: "He doesn't know that the API needs to be updated." },
  { id: 1004, ago: "1 h ago",    action: "translate", pair: "EN → TR", source: "Please review the proposal and get back to me by end of week.", result: "Lütfen teklifi inceleyip hafta sonuna kadar bana geri dönüş yapar mısınız?" },
  { id: 1005, ago: "3 h ago",    action: "custom",    pair: "custom",  source: "hey can you take a look at this when you get a chance thanks", result: "Hello — could you take a look at this when you have a chance? Thank you." },
  { id: 1006, ago: "yesterday",  action: "translate", pair: "DE → EN", source: "Der Vorgang wurde erfolgreich abgeschlossen.", result: "The case was completed successfully." },
  { id: 1007, ago: "yesterday",  action: "translate", pair: "EN → DE", source: "Smart Table is now available in beta.", result: "Smart Table ist jetzt in der Beta verfügbar." },
];

const SEED_GLOSSARY = `# clipboard-translator glossary
# <config_dir>/glossary.toml

[[entry]]
source = "Smart Table"
target = "Smart Table"   # leave product name unchanged
languages = ["*"]

[[entry]]
source = "Vorgang"
target = "case"
languages = ["de->en"]

[[entry]]
source = "case"
target = "Vorgang"
languages = ["en->de"]

[[entry]]
source = "GIP"
target = "GIP"
languages = ["*"]
note = "Always preserve as-is"
`;

Object.assign(window, { SAMPLES, SLOTS, FAKE_RESULTS, SEED_HISTORY, SEED_GLOSSARY });
