// Faux macOS desktop chrome — menu bar, wallpaper, tray icon, dock-less.

const Desktop = ({ children, onTrayClick, onMenuAction, theme, notifications, onDismissNote }) => {
  const [trayOpen, setTrayOpen] = React.useState(false);
  const [appMenuOpen, setAppMenuOpen] = React.useState(false);
  const [now, setNow] = React.useState(() => fmtTime(new Date()));
  React.useEffect(() => {
    const id = setInterval(() => setNow(fmtTime(new Date())), 1000 * 30);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{ ...desktopStyles.root, background: theme === "light" ? desktopStyles.bgLight : desktopStyles.bgDark }}>
      {/* Menu bar */}
      <div style={desktopStyles.menubar}>
        <div style={desktopStyles.menuLeft}>
          <span style={{ ...desktopStyles.appleLogo, opacity: 0.85 }}>◉</span>
          <button style={{ ...desktopStyles.menuItem, fontWeight: 600 }} onClick={() => setAppMenuOpen(v => !v)}>clipt9n</button>
          <span style={desktopStyles.menuItem}>File</span>
          <span style={desktopStyles.menuItem}>Edit</span>
          <span style={desktopStyles.menuItem}>View</span>
          <span style={desktopStyles.menuItem}>Window</span>
          <span style={desktopStyles.menuItem}>Help</span>
          {appMenuOpen && (
            <div style={desktopStyles.appMenu} onMouseLeave={() => setAppMenuOpen(false)}>
              <div style={desktopStyles.menuRow}><span>About clipt9n</span><span style={desktopStyles.menuKbd}>—</span></div>
              <div style={desktopStyles.menuRow}><span>Preferences (config.toml)</span><span style={desktopStyles.menuKbd}>⌘,</span></div>
              <div style={desktopStyles.menuSep} />
              <div style={desktopStyles.menuRow} onClick={() => { setAppMenuOpen(false); onMenuAction && onMenuAction("quit"); }}><span>Quit</span><span style={desktopStyles.menuKbd}>⌘Q</span></div>
            </div>
          )}
        </div>
        <div style={desktopStyles.menuRight}>
          <span style={desktopStyles.menuStatus} title="clipt9n tray">
            <TrayIcon open={trayOpen} onClick={() => { setTrayOpen(v => !v); onTrayClick && onTrayClick(!trayOpen); }} />
          </span>
          <span style={desktopStyles.menuStatus}>⏚</span>
          <span style={desktopStyles.menuStatus}>🔋 92%</span>
          <span style={desktopStyles.menuStatus}>{fmtDate(new Date())}</span>
          <span style={desktopStyles.menuStatus}>{now}</span>
        </div>
      </div>

      {/* Notification stack */}
      <div style={desktopStyles.noteStack}>
        {notifications.map(n => (
          <Notification key={n.id} note={n} onDismiss={() => onDismissNote(n.id)} />
        ))}
      </div>

      {children}
    </div>
  );
};

const TrayIcon = ({ open, onClick }) => (
  <button onClick={onClick} style={{ ...desktopStyles.trayBtn, color: open ? "var(--accent)" : "var(--ink-2)" }} title="clipt9n">
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <rect x="3" y="2" width="10" height="12" rx="1.5" stroke="currentColor" strokeWidth="1.4" />
      <path d="M6 1.5h4v1.5H6z" fill="currentColor" />
      <path d="M5.5 7h5M5.5 9.5h5M5.5 12h3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  </button>
);

const Notification = ({ note, onDismiss }) => (
  <div style={desktopStyles.note} onClick={onDismiss}>
    <div style={desktopStyles.noteIcon}>
      <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
        <rect x="3" y="2" width="10" height="12" rx="1.5" stroke="currentColor" strokeWidth="1.4" />
        <path d="M5.5 7h5M5.5 9.5h5M5.5 12h3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      </svg>
    </div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={desktopStyles.noteTitle}>clipt9n</div>
      <div style={desktopStyles.noteBody}>{note.title}</div>
      {note.detail && <div style={desktopStyles.noteDetail}>{note.detail}</div>}
    </div>
    <div style={desktopStyles.noteTime}>now</div>
  </div>
);

function fmtTime(d) {
  let h = d.getHours(), m = d.getMinutes();
  const ampm = h >= 12 ? "PM" : "AM";
  h = h % 12; if (h === 0) h = 12;
  return `${h}:${String(m).padStart(2, "0")} ${ampm}`;
}
function fmtDate(d) {
  return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}

const desktopStyles = {
  root: {
    position: "absolute", inset: 0, overflow: "hidden",
    fontFamily: "var(--sans)",
  },
  bgDark: "radial-gradient(1200px 800px at 30% 20%, #243049 0%, #131720 55%, #0a0d12 100%)",
  bgLight: "radial-gradient(1200px 800px at 30% 20%, #e8edf6 0%, #cdd6e4 60%, #a9b3c4 100%)",
  menubar: {
    position: "absolute", top: 0, left: 0, right: 0, height: 26,
    background: "rgba(20, 22, 28, 0.55)",
    backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
    color: "#e9ecf1",
    display: "flex", alignItems: "center", justifyContent: "space-between",
    padding: "0 12px",
    fontSize: 13,
    borderBottom: "1px solid rgba(255,255,255,0.06)",
    zIndex: 50,
    userSelect: "none",
  },
  menuLeft: { display: "flex", alignItems: "center", gap: 14, position: "relative" },
  menuRight: { display: "flex", alignItems: "center", gap: 14, fontFeatureSettings: '"tnum"' },
  menuItem: { color: "#e9ecf1", cursor: "default", background: "none", border: 0, padding: 0, fontSize: 13, fontFamily: "inherit" },
  menuStatus: { color: "#e9ecf1", display: "inline-flex", alignItems: "center", gap: 4 },
  appleLogo: { fontSize: 14, marginRight: 2 },
  trayBtn: { background: "none", border: 0, padding: 2, cursor: "pointer", display: "inline-flex" },
  appMenu: {
    position: "absolute", top: 28, left: 32, minWidth: 240,
    background: "rgba(28, 30, 36, 0.92)", backdropFilter: "blur(20px)",
    border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8,
    padding: 4, fontSize: 13, color: "#e9ecf1",
    boxShadow: "0 16px 40px rgba(0,0,0,0.55)",
    zIndex: 60,
  },
  menuRow: { display: "flex", justifyContent: "space-between", padding: "5px 10px", borderRadius: 4, cursor: "default" },
  menuKbd: { color: "#80869294", fontFamily: "var(--mono)", fontSize: 12 },
  menuSep: { height: 1, background: "rgba(255,255,255,0.08)", margin: "4px 0" },

  noteStack: {
    position: "absolute", top: 36, right: 12, width: 320, display: "flex", flexDirection: "column", gap: 8, zIndex: 80, pointerEvents: "none",
  },
  note: {
    pointerEvents: "auto", cursor: "pointer",
    background: "rgba(28, 30, 36, 0.88)", backdropFilter: "blur(20px)",
    border: "1px solid rgba(255,255,255,0.08)", borderRadius: 12,
    padding: "10px 12px", color: "#e9ecf1", fontSize: 12,
    boxShadow: "0 16px 40px rgba(0,0,0,0.45)",
    display: "flex", gap: 10, alignItems: "flex-start",
    animation: "slideIn 280ms ease-out",
  },
  noteIcon: {
    width: 28, height: 28, borderRadius: 6,
    background: "linear-gradient(135deg, #c8ff5e, #8fd944)", color: "#0e1014",
    display: "grid", placeItems: "center",
  },
  noteTitle: { fontSize: 11, color: "#80869294", textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 2 },
  noteBody: { fontSize: 13, fontWeight: 500 },
  noteDetail: { fontSize: 12, color: "#b6bcc7", marginTop: 2, fontFamily: "var(--mono)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  noteTime: { fontSize: 11, color: "#80869294" },
};

// Tray menu — appears under the menu-bar tray icon
const TrayMenu = ({ visible, onClose, onAction, hasKey }) => {
  if (!visible) return null;
  const item = (label, kbd, action, danger) => (
    <div className="trayrow" onClick={() => { onAction(action); onClose(); }} style={{ ...trayStyles.row, color: danger ? "#ff7676" : "#e9ecf1" }}>
      <span>{label}</span>
      {kbd && <span style={trayStyles.kbd}>{kbd}</span>}
    </div>
  );
  return (
    <>
      <div style={trayStyles.scrim} onClick={onClose} />
      <div style={trayStyles.menu}>
        <div style={trayStyles.header}>
          <span style={trayStyles.dot} /> clipt9n
          <span style={trayStyles.headerStatus}>{hasKey ? "ready" : "no API key"}</span>
        </div>
        {item("Translate clipboard", "⌘⇧T", "prompt")}
        {item("Open history", "⌘⇧H", "history")}
        <div style={trayStyles.sep} />
        {item("Open glossary", null, "glossary")}
        {item("Reload glossary", null, "reload-glossary")}
        <div style={trayStyles.sep} />
        {item("Hide icon", null, "hide-tray")}
        {item("Quit", "⌘Q", "quit", true)}
      </div>
      <style>{`
        .trayrow:hover { background: rgba(200, 255, 94, 0.10); }
      `}</style>
    </>
  );
};

const trayStyles = {
  scrim: { position: "absolute", inset: 0, zIndex: 70 },
  menu: {
    position: "absolute", top: 28, right: 12, width: 280, zIndex: 75,
    background: "rgba(20, 22, 28, 0.94)", backdropFilter: "blur(24px)",
    border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10,
    padding: 4, fontSize: 13, color: "#e9ecf1",
    boxShadow: "0 24px 60px rgba(0,0,0,0.55)",
  },
  header: {
    display: "flex", alignItems: "center", gap: 8,
    padding: "8px 12px 6px", fontSize: 12, color: "#80869294",
    textTransform: "uppercase", letterSpacing: 0.8, fontWeight: 600,
    borderBottom: "1px solid rgba(255,255,255,0.06)", marginBottom: 4,
  },
  headerStatus: { marginLeft: "auto", color: "#c8ff5e", fontSize: 10, fontFamily: "var(--mono)", letterSpacing: 0 },
  dot: { width: 6, height: 6, borderRadius: 999, background: "#c8ff5e" },
  row: { display: "flex", justifyContent: "space-between", padding: "7px 12px", borderRadius: 5, cursor: "pointer" },
  kbd: { color: "#80869294", fontFamily: "var(--mono)", fontSize: 11 },
  sep: { height: 1, background: "rgba(255,255,255,0.06)", margin: "4px 0" },
};

Object.assign(window, { Desktop, TrayMenu });
