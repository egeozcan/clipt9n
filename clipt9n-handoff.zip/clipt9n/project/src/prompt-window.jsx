// The hotkey-summoned prompt window.

const PromptWindow = ({ clipboard, lastAction, glossaryHits, onPick, onClose, density }) => {
  const empty = !clipboard || !clipboard.text;
  const preview = empty ? "" : (clipboard.text.length > 110 ? clipboard.text.slice(0, 110) + "…" : clipboard.text);
  const lines = preview.split(/\r?\n/).slice(0, 3);

  // keyboard
  React.useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") { e.preventDefault(); onClose(); return; }
      if (e.key === "Enter") {
        if (lastAction) onPick(lastAction);
        return;
      }
      const n = parseInt(e.key, 10);
      if (n >= 1 && n <= 6 && !empty) {
        e.preventDefault();
        onPick(SLOTS[n - 1]);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [empty, lastAction, onPick, onClose]);

  return (
    <WindowFrame title="Translate clipboard" subtitle="clipt9n · prompt"
      width={density === "compact" ? 460 : 520}
      onClose={onClose} accentDot>
      {empty ? (
        <div style={pw.empty}>
          <div style={pw.emptyIcon}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
              <rect x="5" y="3" width="14" height="18" rx="2" stroke="currentColor" strokeWidth="1.5"/>
              <path d="M9 2.5h6v2H9z" fill="currentColor"/>
              <path d="M9 11l6 6M15 11l-6 6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
            </svg>
          </div>
          <div style={pw.emptyTitle}>Clipboard is empty or not text.</div>
          <div style={pw.emptySub}>Copy something and try again.</div>
          <div style={pw.emptyHint}><kbd style={pw.kbd}>Esc</kbd> to dismiss</div>
        </div>
      ) : (
        <>
          <div style={pw.previewLabel}>
            <span>Clipboard</span>
            <span style={pw.previewMeta}>
              <span style={pw.lang}>{(clipboard.detected || "??").toUpperCase()}</span>
              <span>· {clipboard.text.length} chars</span>
            </span>
          </div>
          <div style={pw.preview}>
            {lines.map((l, i) => (
              <div key={i} style={pw.previewLine}>
                <span style={pw.previewMark}>›</span>
                <span style={pw.previewText}>{l || "\u00A0"}</span>
              </div>
            ))}
          </div>

          <div style={pw.menu}>
            {SLOTS.map((s) => {
              const isLast = lastAction && lastAction.n === s.n;
              return (
                <button key={s.n} onClick={() => onPick(s)} style={{ ...pw.row, ...(isLast ? pw.rowActive : null) }}>
                  <span style={pw.num}>{s.n}</span>
                  <span style={pw.rowLabel}>{s.label}</span>
                  {s.kind === "lang" && <span style={pw.langCode}>{s.code}</span>}
                  {s.kind === "fix" && <span style={pw.tag}>conservative</span>}
                  {s.kind === "rewrite" && <span style={pw.tag}>aggressive</span>}
                  {s.kind === "custom" && <span style={pw.tag}>type instruction</span>}
                  {isLast && <span style={pw.lastBadge}>last used</span>}
                </button>
              );
            })}
          </div>

          {glossaryHits.length > 0 && (
            <div style={pw.glossary}>
              <span style={pw.glossaryLabel}>Glossary will inject:</span>
              {glossaryHits.map((g, i) => (
                <span key={i} style={pw.chip}>
                  <span style={pw.chipSrc}>{g.source}</span>
                  <span style={pw.chipArrow}>→</span>
                  <span style={pw.chipTgt}>{g.target}</span>
                </span>
              ))}
            </div>
          )}

          <div style={pw.footer}>
            <div style={pw.footerLeft}>
              <kbd style={pw.kbd}>1</kbd>–<kbd style={pw.kbd}>6</kbd> pick · <kbd style={pw.kbd}>↵</kbd> {lastAction ? "repeat last" : "—"} · <kbd style={pw.kbd}>Esc</kbd> cancel
            </div>
            <div style={pw.footerRight}>{clipboard.text.length > 2000 && <span style={pw.warn}>⚠ large paste</span>}</div>
          </div>
        </>
      )}
    </WindowFrame>
  );
};

// Reusable window chrome — borderless, always-on-top look, with traffic lights.
const WindowFrame = ({ title, subtitle, width = 520, height, onClose, children, accentDot, plain }) => {
  return (
    <div style={{
      ...wf.frame,
      width,
      height: height || "auto",
    }}>
      <div style={wf.titlebar}>
        <div style={wf.lights}>
          <button onClick={onClose} style={{ ...wf.light, background: "#ff5f57" }} title="close" />
          <span style={{ ...wf.light, background: "#febc2e" }} />
          <span style={{ ...wf.light, background: "#28c840" }} />
        </div>
        <div style={wf.titleWrap}>
          {accentDot && <span style={wf.titleDot} />}
          <span style={wf.title}>{title}</span>
          {subtitle && <span style={wf.subtitle}>{subtitle}</span>}
        </div>
        <div style={wf.titlespacer} />
      </div>
      <div style={{ ...wf.body, padding: plain ? 0 : "14px 18px 16px" }}>{children}</div>
    </div>
  );
};

const wf = {
  frame: {
    background: "linear-gradient(180deg, #1a1d24 0%, #15171c 100%)",
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 12,
    boxShadow: "0 30px 80px rgba(0,0,0,0.6), 0 4px 20px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.04)",
    color: "var(--ink)",
    fontFamily: "var(--sans)",
    overflow: "hidden",
    display: "flex", flexDirection: "column",
  },
  titlebar: {
    display: "grid", gridTemplateColumns: "70px 1fr 70px",
    alignItems: "center", height: 38,
    padding: "0 12px",
    borderBottom: "1px solid rgba(255,255,255,0.05)",
    background: "rgba(20, 22, 28, 0.6)",
  },
  lights: { display: "flex", gap: 6 },
  light: { width: 12, height: 12, borderRadius: 999, border: 0, padding: 0, cursor: "pointer", display: "inline-block" },
  titleWrap: { textAlign: "center", display: "flex", justifyContent: "center", alignItems: "center", gap: 8, fontSize: 12, color: "var(--ink-2)" },
  titleDot: { width: 6, height: 6, borderRadius: 999, background: "var(--accent)" },
  title: { fontWeight: 600, color: "var(--ink)", fontSize: 13 },
  subtitle: { color: "var(--ink-3)", fontFamily: "var(--mono)", fontSize: 11 },
  titlespacer: {},
  body: { padding: "14px 18px 16px" },
};

const pw = {
  previewLabel: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    fontSize: 11, color: "var(--ink-3)", textTransform: "uppercase", letterSpacing: 0.8,
    marginBottom: 6, fontWeight: 600,
  },
  previewMeta: { display: "flex", gap: 6, alignItems: "center", fontFamily: "var(--mono)", textTransform: "none", letterSpacing: 0 },
  lang: {
    background: "rgba(200, 255, 94, 0.12)", color: "var(--accent)",
    padding: "1px 6px", borderRadius: 3, fontSize: 10, fontWeight: 600,
  },
  preview: {
    background: "var(--panel-2)", border: "1px solid var(--line-soft)",
    borderRadius: 6, padding: "10px 12px",
    fontFamily: "var(--mono)", fontSize: 12.5, color: "var(--ink-2)",
    lineHeight: 1.55, marginBottom: 14,
  },
  previewLine: { display: "flex", gap: 8 },
  previewMark: { color: "var(--accent)", opacity: 0.6 },
  previewText: { whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", flex: 1 },

  menu: { display: "flex", flexDirection: "column", gap: 2 },
  row: {
    display: "flex", alignItems: "center", gap: 12,
    padding: "9px 10px",
    background: "transparent", border: "1px solid transparent",
    borderRadius: 6, color: "var(--ink)",
    fontFamily: "inherit", fontSize: 13.5,
    textAlign: "left", cursor: "pointer", width: "100%",
    transition: "background 80ms",
  },
  rowActive: {
    background: "rgba(200, 255, 94, 0.06)",
    border: "1px solid rgba(200, 255, 94, 0.18)",
  },
  num: {
    width: 22, height: 22, display: "grid", placeItems: "center",
    background: "var(--panel-3)", border: "1px solid var(--line)",
    borderRadius: 4, fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-2)",
    fontWeight: 600,
  },
  rowLabel: { flex: 1 },
  langCode: { color: "var(--ink-3)", fontFamily: "var(--mono)", fontSize: 11, textTransform: "uppercase" },
  tag: { color: "var(--ink-3)", fontFamily: "var(--mono)", fontSize: 11 },
  lastBadge: {
    background: "rgba(200, 255, 94, 0.16)", color: "var(--accent)",
    padding: "2px 7px", borderRadius: 999, fontSize: 10,
    fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.8,
  },

  glossary: {
    marginTop: 12, padding: "8px 10px",
    background: "rgba(255, 184, 77, 0.06)", border: "1px solid rgba(255, 184, 77, 0.18)",
    borderRadius: 6, fontSize: 11, color: "var(--ink-2)",
    display: "flex", flexWrap: "wrap", gap: 6, alignItems: "center",
  },
  glossaryLabel: { color: "var(--warn)", fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.8, fontSize: 10, marginRight: 4 },
  chip: {
    display: "inline-flex", alignItems: "center", gap: 5,
    background: "var(--panel-3)", border: "1px solid var(--line)",
    padding: "2px 7px", borderRadius: 4, fontFamily: "var(--mono)", fontSize: 11,
  },
  chipSrc: { color: "var(--ink-2)" },
  chipArrow: { color: "var(--ink-3)" },
  chipTgt: { color: "var(--accent)" },

  footer: {
    marginTop: 12, paddingTop: 10, borderTop: "1px solid var(--line-soft)",
    display: "flex", justifyContent: "space-between", alignItems: "center",
    fontSize: 11, color: "var(--ink-3)", fontFamily: "var(--mono)",
  },
  footerLeft: {},
  footerRight: {},
  warn: { color: "var(--warn)" },
  kbd: {
    background: "var(--panel-3)", border: "1px solid var(--line)",
    padding: "1px 5px", borderRadius: 3, fontFamily: "var(--mono)", fontSize: 10.5,
    color: "var(--ink-2)", margin: "0 2px",
  },

  empty: {
    display: "flex", flexDirection: "column", alignItems: "center", padding: "30px 0 20px",
    color: "var(--ink-2)", textAlign: "center",
  },
  emptyIcon: { color: "var(--bad)", marginBottom: 10, opacity: 0.7 },
  emptyTitle: { fontSize: 14, fontWeight: 500, color: "var(--ink)" },
  emptySub: { fontSize: 12, color: "var(--ink-3)", marginTop: 4 },
  emptyHint: { fontSize: 11, color: "var(--ink-3)", marginTop: 16, fontFamily: "var(--mono)" },
};

// Translating overlay
const TranslatingWindow = ({ action, onCancel }) => {
  const label = action.kind === "lang" ? `Translating to ${action.label}…`
    : action.kind === "fix" ? "Fixing grammar…"
    : action.kind === "rewrite" ? "Rewriting for clarity…"
    : "Running custom prompt…";

  // animated bar
  const [tick, setTick] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 80);
    return () => clearInterval(id);
  }, []);
  const cells = 16;
  const fill = ((tick % cells));

  return (
    <WindowFrame title={label} subtitle="claude-haiku-4-5" width={460} onClose={onCancel} accentDot>
      <div style={tw.body}>
        <div style={tw.bar}>
          {Array.from({ length: cells }).map((_, i) => {
            const dist = (i - fill + cells) % cells;
            const intensity = dist < 4 ? (4 - dist) / 4 : 0;
            return <span key={i} style={{ ...tw.cell, opacity: 0.15 + intensity * 0.85 }} />;
          })}
        </div>
        <div style={tw.meta}>
          <span>request → api.anthropic.com</span>
          <span>{(tick * 80 / 1000).toFixed(1)}s</span>
        </div>
      </div>
    </WindowFrame>
  );
};

const tw = {
  body: { padding: "16px 4px 4px" },
  bar: { display: "flex", gap: 3, marginBottom: 12 },
  cell: { flex: 1, height: 16, background: "var(--accent)", borderRadius: 2 },
  meta: { display: "flex", justifyContent: "space-between", color: "var(--ink-3)", fontFamily: "var(--mono)", fontSize: 11 },
};

Object.assign(window, { PromptWindow, WindowFrame, TranslatingWindow });
