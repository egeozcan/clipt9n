// History viewer

const HistoryWindow = ({ entries, onCopyResult, onCopySource, onDelete, onClearAll, onClose }) => {
  const [query, setQuery] = React.useState("");
  const [sel, setSel] = React.useState(0);
  const [confirmClear, setConfirmClear] = React.useState(false);

  const filtered = React.useMemo(() => {
    if (!query.trim()) return entries;
    const q = query.toLowerCase();
    return entries.filter(e =>
      e.source.toLowerCase().includes(q) ||
      e.result.toLowerCase().includes(q) ||
      e.pair.toLowerCase().includes(q)
    );
  }, [entries, query]);

  React.useEffect(() => { if (sel >= filtered.length) setSel(0); }, [filtered.length, sel]);

  const onKey = (e) => {
    if (e.key === "Escape") { if (confirmClear) { setConfirmClear(false); return; } e.preventDefault(); onClose(); return; }
    if (confirmClear) {
      if (e.key === "Enter") { e.preventDefault(); onClearAll(); setConfirmClear(false); }
      return;
    }
    if (e.key === "ArrowDown") { e.preventDefault(); setSel(s => Math.min(s + 1, filtered.length - 1)); }
    if (e.key === "ArrowUp")   { e.preventDefault(); setSel(s => Math.max(s - 1, 0)); }
    if (e.key === "Enter")     { if (filtered[sel]) onCopyResult(filtered[sel]); }
    if (e.key === "s" && !e.metaKey && !e.ctrlKey) { if (filtered[sel]) onCopySource(filtered[sel]); }
    if (e.key === "d" && !e.metaKey && !e.ctrlKey) { if (filtered[sel]) onDelete(filtered[sel].id); }
    if (e.key === "Delete" && e.shiftKey) { setConfirmClear(true); }
  };

  return (
    <div tabIndex={0} onKeyDown={onKey} style={{ outline: "none" }} ref={(n) => n && n.focus()}>
      <WindowFrame title="History" subtitle={`${entries.length} entries · encrypted`} width={680} onClose={onClose} accentDot>
        <div style={hw.searchRow}>
          <span style={hw.searchIcon}>⌕</span>
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="type to filter…"
            style={hw.search}
          />
          {query && <span style={hw.searchHits}>{filtered.length} hit{filtered.length === 1 ? "" : "s"}</span>}
        </div>
        <div style={hw.list}>
          {filtered.length === 0 && (
            <div style={hw.emptyList}>No matches. <kbd style={hw.kbd}>Esc</kbd> to close.</div>
          )}
          {filtered.map((e, i) => {
            const active = i === sel;
            return (
              <div key={e.id} onClick={() => setSel(i)} onDoubleClick={() => onCopyResult(e)}
                style={{ ...hw.row, ...(active ? hw.rowActive : null) }}>
                <span style={hw.mark}>{active ? "▸" : " "}</span>
                <span style={hw.ago}>{e.ago}</span>
                <span style={{ ...hw.pair, ...pairStyle(e.action) }}>{e.pair}</span>
                <span style={hw.text}>
                  <Highlight text={e.source} q={query} />
                </span>
              </div>
            );
          })}
        </div>

        {filtered[sel] && (
          <div style={hw.detail}>
            <div style={hw.detailCol}>
              <div style={hw.detailLabel}>SOURCE</div>
              <div style={hw.detailText}>{filtered[sel].source}</div>
            </div>
            <div style={hw.detailDivider} />
            <div style={hw.detailCol}>
              <div style={hw.detailLabel}>RESULT</div>
              <div style={hw.detailText}>{filtered[sel].result}</div>
            </div>
          </div>
        )}

        <div style={hw.footer}>
          <span><kbd style={hw.kbd}>↵</kbd> copy result</span>
          <span><kbd style={hw.kbd}>s</kbd> copy source</span>
          <span><kbd style={hw.kbd}>d</kbd> delete</span>
          <span><kbd style={hw.kbd}>⇧</kbd>+<kbd style={hw.kbd}>Del</kbd> clear all</span>
          <span style={{ marginLeft: "auto" }}><kbd style={hw.kbd}>Esc</kbd> close</span>
        </div>

        {confirmClear && (
          <div style={hw.modalScrim}>
            <div style={hw.modal}>
              <div style={hw.modalTitle}>Clear all history?</div>
              <div style={hw.modalBody}>{entries.length} entries will be permanently removed. The encryption key stays in place.</div>
              <div style={hw.modalActions}>
                <button onClick={() => setConfirmClear(false)} style={hw.modalBtn}>Cancel</button>
                <button onClick={() => { onClearAll(); setConfirmClear(false); }} style={{ ...hw.modalBtn, ...hw.modalBtnDanger }}>Clear all</button>
              </div>
            </div>
          </div>
        )}
      </WindowFrame>
    </div>
  );
};

const Highlight = ({ text, q }) => {
  if (!q.trim()) return <>{text}</>;
  const parts = text.split(new RegExp(`(${q.replace(/[.*+?^${}()|[\\]\\\\]/g, "\\$&")})`, "ig"));
  return parts.map((p, i) => p.toLowerCase() === q.toLowerCase()
    ? <mark key={i} style={{ background: "rgba(200,255,94,0.25)", color: "inherit" }}>{p}</mark>
    : <span key={i}>{p}</span>);
};

function pairStyle(action) {
  if (action === "fix_grammar") return { color: "#9ad6ff" };
  if (action === "rewrite") return { color: "#d4a8ff" };
  if (action === "custom") return { color: "#ffb84d" };
  return { color: "var(--accent)" };
}

const hw = {
  searchRow: { display: "flex", alignItems: "center", gap: 8, padding: "0 0 10px", borderBottom: "1px solid var(--line-soft)" },
  searchIcon: { fontFamily: "var(--mono)", color: "var(--ink-3)", fontSize: 14 },
  search: {
    flex: 1, background: "transparent", border: 0, outline: 0,
    color: "var(--ink)", fontSize: 13, fontFamily: "var(--mono)", padding: "6px 0",
  },
  searchHits: { fontSize: 11, color: "var(--ink-3)", fontFamily: "var(--mono)" },
  list: { maxHeight: 250, overflowY: "auto", padding: "6px 0", margin: "0 -4px" },
  emptyList: { padding: 24, textAlign: "center", color: "var(--ink-3)", fontSize: 12 },
  row: {
    display: "grid", gridTemplateColumns: "16px 90px 90px 1fr", gap: 10,
    padding: "6px 8px", borderRadius: 4, alignItems: "center",
    fontSize: 12.5, color: "var(--ink-2)", cursor: "pointer",
  },
  rowActive: { background: "rgba(200, 255, 94, 0.06)", color: "var(--ink)" },
  mark: { color: "var(--accent)", fontFamily: "var(--mono)", textAlign: "center" },
  ago: { color: "var(--ink-3)", fontFamily: "var(--mono)", fontSize: 11 },
  pair: { fontFamily: "var(--mono)", fontSize: 11, fontWeight: 600 },
  text: { whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  detail: {
    marginTop: 10, display: "grid", gridTemplateColumns: "1fr 1px 1fr", gap: 12,
    padding: "10px 12px", background: "var(--panel-2)", borderRadius: 6, border: "1px solid var(--line-soft)",
  },
  detailCol: { minWidth: 0 },
  detailDivider: { background: "var(--line)" },
  detailLabel: { fontSize: 10, color: "var(--ink-3)", textTransform: "uppercase", letterSpacing: 0.8, fontWeight: 600, marginBottom: 4 },
  detailText: { fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink)", lineHeight: 1.55, maxHeight: 80, overflow: "auto" },
  footer: {
    marginTop: 12, paddingTop: 10, borderTop: "1px solid var(--line-soft)",
    display: "flex", gap: 14, alignItems: "center",
    fontSize: 11, color: "var(--ink-3)", fontFamily: "var(--mono)",
  },
  kbd: { background: "var(--panel-3)", border: "1px solid var(--line)", padding: "1px 5px", borderRadius: 3, fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-2)", margin: "0 2px" },

  modalScrim: { position: "absolute", inset: 0, background: "rgba(0,0,0,0.55)", display: "grid", placeItems: "center", borderRadius: 12 },
  modal: { background: "var(--panel)", border: "1px solid var(--line)", borderRadius: 8, padding: 18, width: 360, boxShadow: "0 30px 60px rgba(0,0,0,0.5)" },
  modalTitle: { fontSize: 14, fontWeight: 600, marginBottom: 6 },
  modalBody: { fontSize: 12.5, color: "var(--ink-2)", lineHeight: 1.5, marginBottom: 14 },
  modalActions: { display: "flex", gap: 8, justifyContent: "flex-end" },
  modalBtn: { background: "var(--panel-3)", color: "var(--ink)", border: "1px solid var(--line)", padding: "6px 12px", borderRadius: 5, fontFamily: "inherit", fontSize: 12.5, cursor: "pointer" },
  modalBtnDanger: { background: "var(--bad)", color: "#0e1014", borderColor: "transparent", fontWeight: 600 },
};

Object.assign(window, { HistoryWindow });
