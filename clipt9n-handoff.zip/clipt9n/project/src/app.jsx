// Top-level app — composes desktop + windows + state machine.

const { useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle, TweakSelect, TweakSlider, TweakColor, TweakButton } = window;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#c8ff5e",
  "theme": "dark",
  "density": "regular",
  "showPreview": true,
  "rememberLast": true,
  "sample": "de_greeting",
  "fontStack": "inter+jetbrains",
  "showAllWindows": false
}/*EDITMODE-END*/;

const App = () => {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // app state
  const [hasKey, setHasKey] = React.useState(true);
  const [openWindow, setOpenWindow] = React.useState(null); // null | 'prompt' | 'translating' | 'history' | 'setup' | 'glossary' | 'custom'
  const [trayOpen, setTrayOpen] = React.useState(false);
  const [trayVisible, setTrayVisible] = React.useState(true);
  const [pendingAction, setPendingAction] = React.useState(null);
  const [lastAction, setLastAction] = React.useState({ n: 2, kind: "lang", label: "Deutsch", code: "de" });
  const [history, setHistory] = React.useState(SEED_HISTORY);
  const [glossary, setGlossary] = React.useState(SEED_GLOSSARY);
  const [notes, setNotes] = React.useState([]);
  const [clipboard, setClipboard] = React.useState(SAMPLES[0]);

  // accent css var
  React.useEffect(() => {
    document.documentElement.style.setProperty("--accent", tweaks.accent);
  }, [tweaks.accent]);

  // pick clipboard from tweak
  React.useEffect(() => {
    const s = SAMPLES.find(s => s.id === tweaks.sample) || SAMPLES[0];
    setClipboard(s);
  }, [tweaks.sample]);

  // global hotkey simulation: ⌘⇧T / ⌘⇧H. Also ⌘⇧S for setup, ⌘⇧G for glossary.
  React.useEffect(() => {
    const onKey = (e) => {
      const cmd = e.metaKey || e.ctrlKey;
      if (cmd && e.shiftKey && (e.key === "T" || e.key === "t")) {
        e.preventDefault();
        if (!hasKey) { setOpenWindow("setup"); return; }
        setOpenWindow(prev => prev === "prompt" ? null : "prompt");
      }
      if (cmd && e.shiftKey && (e.key === "H" || e.key === "h")) {
        e.preventDefault();
        setOpenWindow(prev => prev === "history" ? null : "history");
      }
      if (cmd && e.shiftKey && (e.key === "G" || e.key === "g")) {
        e.preventDefault();
        setOpenWindow("glossary");
      }
      if (cmd && e.shiftKey && (e.key === "S" || e.key === "s")) {
        e.preventDefault();
        setOpenWindow("setup");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [hasKey]);

  const pushNote = (note) => {
    const id = Date.now() + Math.random();
    setNotes(n => [...n, { id, ...note }]);
    setTimeout(() => setNotes(n => n.filter(x => x.id !== id)), 4500);
  };
  const dismissNote = (id) => setNotes(n => n.filter(x => x.id !== id));

  // glossary hits — what would inject for current clipboard + target lang
  const glossaryHits = React.useMemo(() => {
    if (!clipboard.text) return [];
    const all = [
      { source: "Smart Table", target: "Smart Table", scope: "*" },
      { source: "Vorgang", target: "case", scope: "de->en" },
      { source: "case", target: "Vorgang", scope: "en->de" },
      { source: "GIP", target: "GIP", scope: "*" },
    ];
    return all.filter(g => clipboard.text.toLowerCase().includes(g.source.toLowerCase()));
  }, [clipboard]);

  const onPick = (slot) => {
    if (slot.kind === "custom") { setOpenWindow("custom"); return; }
    runAction(slot, null);
  };

  const runAction = (slot, customInstruction) => {
    setPendingAction({ ...slot, customInstruction });
    if (tweaks.rememberLast && slot.kind !== "custom") setLastAction(slot);
    setOpenWindow("translating");
    // simulate latency
    const latency = 700 + Math.random() * 600;
    setTimeout(() => {
      const sampleId = clipboard.id;
      let key;
      if (slot.kind === "lang") key = `${sampleId}>${slot.code}`;
      else if (slot.kind === "fix") key = `${sampleId}>fix`;
      else if (slot.kind === "rewrite") key = `${sampleId}>rewrite`;
      else key = `${sampleId}>custom`;
      const result = FAKE_RESULTS[key] || `[translated] ${clipboard.text}`;

      // record history
      const pair = slot.kind === "lang" ? `${(clipboard.detected || "??").toUpperCase()} → ${slot.code.toUpperCase()}`
        : slot.kind === "fix" ? "grammar"
        : slot.kind === "rewrite" ? "rewrite" : "custom";
      const action = slot.kind === "lang" ? "translate" : slot.kind === "fix" ? "fix_grammar" : slot.kind === "rewrite" ? "rewrite" : "custom";
      setHistory(h => [{ id: Date.now(), ago: "just now", action, pair, source: clipboard.text, result }, ...h].slice(0, 100));

      pushNote({ title: "Translation copied", detail: result.slice(0, 70) + (result.length > 70 ? "…" : "") });
      setOpenWindow(null);
      setPendingAction(null);
    }, latency);
  };

  const onCustomSubmit = (instruction) => {
    runAction({ n: 6, kind: "custom", label: "Custom prompt" }, instruction);
  };

  const onTrayAction = (a) => {
    if (a === "prompt") setOpenWindow("prompt");
    if (a === "history") setOpenWindow("history");
    if (a === "glossary") setOpenWindow("glossary");
    if (a === "reload-glossary") { pushNote({ title: "Glossary reloaded", detail: `${(glossary.match(/\[\[entry\]\]/g) || []).length} entries` }); }
    if (a === "hide-tray") { setTrayVisible(false); pushNote({ title: "Tray hidden", detail: "Cmd+Shift+T still works · --show-tray to restore" }); }
    if (a === "quit") pushNote({ title: "Quit", detail: "(this is a prototype — nothing actually quits)" });
  };

  const showAll = tweaks.showAllWindows;

  return (
    <Desktop theme={tweaks.theme} notifications={notes} onDismissNote={dismissNote}
      onTrayClick={(o) => setTrayOpen(o)} onMenuAction={(a) => onTrayAction(a)}>

      <DesktopBackplate hasKey={hasKey} onSummon={(w) => setOpenWindow(w)}
        clipboard={clipboard} lastAction={lastAction} trayVisible={trayVisible}
        onResetSetup={() => { setHasKey(false); setOpenWindow("setup"); }}
      />

      {/* Floating windows — show all in compare mode, otherwise the active one */}
      <WindowStage>
        {(showAll || openWindow === "prompt") && (
          <Floater key="prompt" pos={showAll ? { left: 80, top: 80 } : "center"}>
            <PromptWindow
              clipboard={clipboard}
              lastAction={tweaks.rememberLast ? lastAction : null}
              glossaryHits={glossaryHits}
              onPick={onPick}
              onClose={() => setOpenWindow(null)}
              density={tweaks.density}
            />
          </Floater>
        )}
        {(showAll || openWindow === "translating") && pendingAction && (
          <Floater key="translating" pos={showAll ? { right: 80, top: 80 } : "center"}>
            <TranslatingWindow action={pendingAction} onCancel={() => { setOpenWindow(null); setPendingAction(null); }} />
          </Floater>
        )}
        {(showAll || openWindow === "history") && (
          <Floater key="history" pos={showAll ? { left: 80, top: 460 } : "center"}>
            <HistoryWindow
              entries={history}
              onCopyResult={(e) => { pushNote({ title: "Result copied", detail: e.result.slice(0, 70) }); setOpenWindow(null); }}
              onCopySource={(e) => { pushNote({ title: "Source copied", detail: e.source.slice(0, 70) }); }}
              onDelete={(id) => setHistory(h => h.filter(x => x.id !== id))}
              onClearAll={() => { setHistory([]); pushNote({ title: "History cleared", detail: "All entries removed" }); }}
              onClose={() => setOpenWindow(null)}
            />
          </Floater>
        )}
        {(showAll || openWindow === "custom") && (
          <Floater key="custom" pos={showAll ? { right: 80, top: 460 } : "center"}>
            <CustomPromptWindow
              clipboard={clipboard}
              onSubmit={(t) => { onCustomSubmit(t); }}
              onClose={() => setOpenWindow(null)}
            />
          </Floater>
        )}
        {(showAll || openWindow === "setup") && (
          <Floater key="setup" pos={showAll ? { left: 700, top: 80 } : "center"}>
            <SetupWizard
              onClose={() => setOpenWindow(null)}
              onComplete={() => { setHasKey(true); setOpenWindow(null); pushNote({ title: "Setup complete", detail: "API key saved to Keychain" }); }}
            />
          </Floater>
        )}
        {(showAll || openWindow === "glossary") && (
          <Floater key="glossary" pos={showAll ? { left: 700, top: 460 } : "center"}>
            <GlossaryWindow
              contents={glossary}
              onClose={() => setOpenWindow(null)}
              onSave={(t) => { setGlossary(t); pushNote({ title: "Glossary saved", detail: "Will be picked up on reload" }); }}
              onReload={() => pushNote({ title: "Glossary reloaded", detail: "from disk" })}
            />
          </Floater>
        )}
      </WindowStage>

      {/* Tray menu */}
      {trayVisible && trayOpen && (
        <TrayMenu visible onClose={() => setTrayOpen(false)} onAction={onTrayAction} hasKey={hasKey} />
      )}

      {/* Tweaks */}
      <TweaksPanel>
        <TweakSection label="Look" />
        <TweakColor label="Accent" value={tweaks.accent} onChange={(v) => setTweak("accent", v)} />
        <TweakRadio label="Theme" value={tweaks.theme} onChange={(v) => setTweak("theme", v)} options={[{value: "dark", label: "Dark"}, {value: "light", label: "Light"}]} />
        <TweakRadio label="Density" value={tweaks.density} onChange={(v) => setTweak("density", v)} options={[{value: "regular", label: "Regular"}, {value: "compact", label: "Compact"}]} />
        <TweakSection label="Behavior" />
        <TweakToggle label="Show source preview" value={tweaks.showPreview} onChange={(v) => setTweak("showPreview", v)} />
        <TweakToggle label="Remember last action" value={tweaks.rememberLast} onChange={(v) => setTweak("rememberLast", v)} />
        <TweakSection label="Demo" />
        <TweakSelect label="Clipboard sample" value={tweaks.sample} onChange={(v) => setTweak("sample", v)}
          options={SAMPLES.map(s => ({ value: s.id, label: s.label }))} />
        <TweakToggle label="Show all windows" value={tweaks.showAllWindows} onChange={(v) => setTweak("showAllWindows", v)} />
        <TweakButton label="Trigger setup wizard" onClick={() => { setHasKey(false); setOpenWindow("setup"); }} />
        <TweakButton label="Open custom prompt" onClick={() => setOpenWindow("custom")} />
      </TweaksPanel>
    </Desktop>
  );
};

// Backplate — desktop hint card explaining keyboard surfaces
const DesktopBackplate = ({ hasKey, onSummon, clipboard, lastAction, trayVisible, onResetSetup }) => {
  return (
    <div style={bp.wrap}>
      <div style={bp.heroLeft}>
        <div style={bp.kicker}>clipt9n · prototype</div>
        <div style={bp.h1}>Clipboard Translator</div>
        <div style={bp.sub}>A global-hotkey clipboard tool. Press a key combo, pick a target, get the result back on the clipboard. Try the surfaces below.</div>

        <div style={bp.shortcutGrid}>
          <ShortcutCard label="Translate clipboard" kbd={["⌘", "⇧", "T"]} onClick={() => onSummon("prompt")} />
          <ShortcutCard label="History viewer" kbd={["⌘", "⇧", "H"]} onClick={() => onSummon("history")} />
          <ShortcutCard label="Glossary editor" kbd={["⌘", "⇧", "G"]} onClick={() => onSummon("glossary")} muted />
          <ShortcutCard label="Setup wizard" kbd={["⌘", "⇧", "S"]} onClick={onResetSetup} muted />
        </div>

        <div style={bp.statusRow}>
          <StatusPill ok={hasKey} label={hasKey ? "API key in Keychain" : "no API key"} />
          <StatusPill ok={trayVisible} label={trayVisible ? "tray visible" : "tray hidden"} />
          <StatusPill ok label={`last action · ${lastAction ? lastAction.label : "—"}`} />
          <StatusPill ok label={`clipboard · ${clipboard.detected ? clipboard.detected.toUpperCase() : "empty"} · ${clipboard.text.length} chars`} />
        </div>
      </div>

      <div style={bp.heroRight}>
        <div style={bp.diagramTitle}>arch · v1</div>
        <DiagramFlow />
      </div>
    </div>
  );
};

const ShortcutCard = ({ label, kbd, onClick, muted }) => (
  <button onClick={onClick} style={{ ...bp.card, ...(muted ? bp.cardMuted : null) }}>
    <span style={bp.cardLabel}>{label}</span>
    <span style={bp.cardKbd}>
      {kbd.map((k, i) => <kbd key={i} style={bp.kbd}>{k}</kbd>)}
    </span>
  </button>
);

const StatusPill = ({ ok, label }) => (
  <span style={{ ...bp.pill, color: ok ? "var(--good)" : "var(--bad)" }}>
    <span style={{ width: 6, height: 6, borderRadius: 999, background: "currentColor" }} /> {label}
  </span>
);

const DiagramFlow = () => (
  <div style={bp.diagram}>
    {[
      ["1", "hotkey", "⌘⇧T"],
      ["2", "read clipboard", "arboard"],
      ["3", "prompt window", "egui"],
      ["4", "render template", "minijinja"],
      ["5", "+ glossary block", "auto match"],
      ["6", "API call", "claude-haiku-4-5"],
      ["7", "post-process", "trim · dequote"],
      ["8", "write clipboard", "+ encrypted history"],
      ["9", "OS notify", "notify-rust"],
    ].map(([n, label, sub]) => (
      <div key={n} style={bp.diagramRow}>
        <span style={bp.diagramNum}>{n}</span>
        <span style={bp.diagramLabel}>{label}</span>
        <span style={bp.diagramSub}>{sub}</span>
      </div>
    ))}
  </div>
);

const bp = {
  wrap: {
    position: "absolute", top: 60, left: 40, right: 40, bottom: 40,
    display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 36,
    color: "var(--ink)",
  },
  heroLeft: { display: "flex", flexDirection: "column", gap: 14, justifyContent: "flex-start", paddingTop: 30, maxWidth: 720 },
  kicker: { fontSize: 11, color: "var(--ink-3)", letterSpacing: 1.4, fontWeight: 600, fontFamily: "var(--mono)" },
  h1: { fontSize: 56, fontWeight: 700, letterSpacing: -1.2, lineHeight: 1.02, margin: "4px 0 8px", color: "var(--ink)" },
  sub: { fontSize: 15, color: "var(--ink-2)", maxWidth: 520, lineHeight: 1.5, marginBottom: 8 },

  shortcutGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, maxWidth: 540, marginTop: 12 },
  card: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "12px 14px",
    background: "rgba(28, 32, 40, 0.55)", backdropFilter: "blur(20px)",
    border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8,
    color: "var(--ink)", fontFamily: "inherit", fontSize: 13.5,
    cursor: "pointer", textAlign: "left",
  },
  cardMuted: { opacity: 0.7 },
  cardLabel: { fontWeight: 500 },
  cardKbd: { display: "flex", gap: 3 },
  kbd: { background: "var(--panel-3)", border: "1px solid var(--line)", padding: "1px 6px", borderRadius: 3, fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-2)" },

  statusRow: { display: "flex", flexWrap: "wrap", gap: 6, marginTop: 16 },
  pill: {
    display: "inline-flex", alignItems: "center", gap: 6,
    padding: "3px 9px", background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.06)", borderRadius: 999,
    fontSize: 11, fontFamily: "var(--mono)",
  },

  heroRight: { display: "flex", flexDirection: "column", gap: 10, paddingTop: 30 },
  diagramTitle: { fontSize: 10, color: "var(--ink-3)", letterSpacing: 1.2, fontWeight: 600, fontFamily: "var(--mono)" },
  diagram: {
    background: "rgba(20, 22, 28, 0.55)", backdropFilter: "blur(20px)",
    border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10,
    padding: "10px 14px", display: "flex", flexDirection: "column",
  },
  diagramRow: {
    display: "grid", gridTemplateColumns: "26px 1fr auto", alignItems: "center", gap: 10,
    padding: "7px 0", borderBottom: "1px dashed var(--line-soft)", fontSize: 12.5,
  },
  diagramNum: { fontFamily: "var(--mono)", color: "var(--accent)", fontSize: 11 },
  diagramLabel: { color: "var(--ink)" },
  diagramSub: { fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-3)" },
};

const WindowStage = ({ children }) => <div style={{ position: "absolute", inset: 0, pointerEvents: "none", zIndex: 30 }}>{children}</div>;

const Floater = ({ pos, children }) => {
  const style = pos === "center" ? {
    position: "absolute", left: "50%", top: "50%", transform: "translate(-50%, -50%)",
    pointerEvents: "auto",
    animation: "popIn 160ms ease-out",
  } : {
    position: "absolute", ...pos, pointerEvents: "auto",
  };
  return <div style={style}>{children}</div>;
};

// keyframes
const styleEl = document.createElement("style");
styleEl.textContent = `
  @keyframes popIn { from { opacity: 0; transform: translate(-50%, -48%) scale(0.98); } to { opacity: 1; transform: translate(-50%, -50%) scale(1); } }
  @keyframes slideIn { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
  ::-webkit-scrollbar { width: 8px; height: 8px; }
  ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.08); border-radius: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
`;
document.head.appendChild(styleEl);

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
