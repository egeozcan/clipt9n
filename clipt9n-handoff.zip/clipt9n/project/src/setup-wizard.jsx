// First-launch setup wizard

const SetupWizard = ({ onClose, onComplete }) => {
  const [provider, setProvider] = React.useState("anthropic");
  const [key, setKey] = React.useState("");
  const [show, setShow] = React.useState(false);
  const [storage, setStorage] = React.useState("keychain");
  const [testRequested, setTestRequested] = React.useState(true);
  const [phase, setPhase] = React.useState("entry"); // entry | verifying | done | error
  const [check1, setCheck1] = React.useState("idle"); // idle running ok fail
  const [check2, setCheck2] = React.useState("idle");
  const [errMsg, setErrMsg] = React.useState("");

  const startVerify = () => {
    setPhase("verifying");
    setCheck1("running"); setCheck2("idle"); setErrMsg("");

    setTimeout(() => {
      // simulate failure for obviously-bad keys
      if (!key || key.length < 8) {
        setCheck1("fail");
        setErrMsg("401 Invalid API key");
        setPhase("error");
        return;
      }
      setCheck1("ok");
      if (!testRequested) { setPhase("done"); return; }
      setCheck2("running");
      setTimeout(() => {
        setCheck2("ok");
        setPhase("done");
      }, 1100);
    }, 700);
  };

  const onSave = () => {
    onComplete({ provider, storage });
  };

  const providers = [
    { id: "anthropic", label: "Anthropic (Claude)" },
    { id: "openai",    label: "OpenAI" },
    { id: "gemini",    label: "Google Gemini (OpenAI-compat)" },
    { id: "ollama",    label: "Ollama (local)" },
  ];

  return (
    <WindowFrame title="Welcome to clipt9n" subtitle="first-run · setup" width={580} onClose={onClose} accentDot>
      <div style={sw.intro}>
        <div style={sw.kicker}>STEP 1 OF 3 · PROVIDER</div>
        <div style={sw.h1}>Pick your translation provider.</div>
      </div>

      <div style={sw.providerGrid}>
        {providers.map(p => (
          <button key={p.id} onClick={() => setProvider(p.id)}
            style={{ ...sw.provider, ...(provider === p.id ? sw.providerActive : null) }}>
            <span style={sw.providerDot} />
            <span style={sw.providerLabel}>{p.label}</span>
            {p.id === "anthropic" && <span style={sw.providerBadge}>recommended</span>}
            {p.id === "ollama" && <span style={{ ...sw.providerBadge, background: "rgba(154,214,255,0.12)", color: "#9ad6ff" }}>offline</span>}
          </button>
        ))}
      </div>
      <a style={sw.link}>Get your API key →</a>

      <div style={sw.divider} />

      <div style={sw.kicker}>STEP 2 · KEY</div>
      <div style={sw.keyRow}>
        <input
          type={show ? "text" : "password"}
          value={key}
          onChange={(e) => { setKey(e.target.value); if (phase !== "entry") setPhase("entry"); }}
          placeholder="sk-ant-…"
          style={sw.keyInput}
        />
        <button onClick={() => setShow(s => !s)} style={sw.showBtn}>{show ? "hide" : "show"}</button>
      </div>
      <div style={sw.storageRow}>
        <label style={{ ...sw.storageOpt, ...(storage === "keychain" ? sw.storageActive : null) }}>
          <input type="radio" checked={storage === "keychain"} onChange={() => setStorage("keychain")} style={sw.radio} />
          <div>
            <div style={sw.storageTitle}>macOS Keychain <span style={sw.recBadge}>recommended</span></div>
            <div style={sw.storageSub}>Bound to clipt9n bundle id; other apps prompted on read.</div>
          </div>
        </label>
        <label style={{ ...sw.storageOpt, ...(storage === "env" ? sw.storageActive : null) }}>
          <input type="radio" checked={storage === "env"} onChange={() => setStorage("env")} style={sw.radio} />
          <div>
            <div style={sw.storageTitle}>Environment variable</div>
            <div style={sw.storageSub}><span style={{ fontFamily: "var(--mono)" }}>$ANTHROPIC_API_KEY</span></div>
          </div>
        </label>
      </div>

      <div style={sw.divider} />

      <div style={sw.kicker}>STEP 3 · VERIFY</div>
      <label style={sw.testCheck}>
        <input type="checkbox" checked={testRequested} onChange={(e) => setTestRequested(e.target.checked)} />
        <span>Test with a real translation <span style={sw.faint}>(~$0.0001 in tokens, recommended)</span></span>
      </label>

      <div style={sw.checks}>
        <CheckRow label="Connectivity (auth)" status={check1} detail="POST /v1/messages · max_tokens 1" />
        {testRequested && <CheckRow label="Sample translation" status={check2} detail={'"Hello, world." → "Hallo, Welt."'} />}
      </div>

      {phase === "error" && (
        <div style={sw.errBox}>
          <span style={sw.errIcon}>!</span>
          <div>
            <div style={sw.errTitle}>{errMsg}</div>
            <div style={sw.errBody}>Try a different key, or open <span style={{ fontFamily: "var(--mono)" }}>config.toml</span> to switch provider.</div>
          </div>
        </div>
      )}

      <div style={sw.footer}>
        <button onClick={onClose} style={sw.cancel}>Cancel</button>
        <div style={{ flex: 1 }} />
        {phase !== "done" && (
          <button onClick={startVerify} disabled={!key || phase === "verifying"} style={{ ...sw.primary, ...(!key || phase === "verifying" ? sw.primaryDisabled : null) }}>
            {phase === "verifying" ? "Verifying…" : "Verify →"}
          </button>
        )}
        {phase === "done" && (
          <button onClick={onSave} style={{ ...sw.primary, background: "var(--good)" }}>Save and start ✓</button>
        )}
      </div>
    </WindowFrame>
  );
};

const CheckRow = ({ label, status, detail }) => {
  let dot, color;
  if (status === "idle") { dot = "○"; color = "var(--ink-3)"; }
  else if (status === "running") { dot = "◐"; color = "var(--warn)"; }
  else if (status === "ok") { dot = "✓"; color = "var(--good)"; }
  else { dot = "✕"; color = "var(--bad)"; }
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "7px 0", borderTop: "1px dashed var(--line-soft)" }}>
      <span style={{ width: 18, color, fontFamily: "var(--mono)", fontSize: 13, fontWeight: 600 }}>{dot}</span>
      <span style={{ flex: 1, fontSize: 13 }}>{label}</span>
      <span style={{ color: "var(--ink-3)", fontFamily: "var(--mono)", fontSize: 11 }}>{detail}</span>
    </div>
  );
};

const sw = {
  intro: { marginBottom: 12 },
  kicker: { fontSize: 10, color: "var(--ink-3)", letterSpacing: 1.2, fontWeight: 600, marginBottom: 6, fontFamily: "var(--mono)" },
  h1: { fontSize: 16, fontWeight: 600, marginBottom: 0 },
  providerGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 8 },
  provider: {
    display: "flex", alignItems: "center", gap: 10,
    padding: "9px 12px",
    background: "var(--panel-2)", color: "var(--ink)",
    border: "1px solid var(--line-soft)", borderRadius: 6,
    cursor: "pointer", fontSize: 13, fontFamily: "inherit", textAlign: "left",
  },
  providerActive: { borderColor: "var(--accent)", background: "rgba(200, 255, 94, 0.06)" },
  providerDot: { width: 8, height: 8, borderRadius: 999, background: "var(--accent)" },
  providerLabel: { flex: 1 },
  providerBadge: {
    background: "rgba(200, 255, 94, 0.12)", color: "var(--accent)",
    padding: "1px 6px", borderRadius: 999, fontSize: 10, fontFamily: "var(--mono)", fontWeight: 600,
  },
  link: { color: "var(--accent)", fontSize: 12, fontFamily: "var(--mono)", cursor: "pointer", textDecoration: "none" },
  divider: { height: 1, background: "var(--line-soft)", margin: "14px 0 12px" },

  keyRow: { display: "flex", gap: 6, marginBottom: 10 },
  keyInput: {
    flex: 1, background: "var(--panel-2)", color: "var(--ink)",
    border: "1px solid var(--line)", borderRadius: 5,
    padding: "8px 10px", fontFamily: "var(--mono)", fontSize: 13, outline: "none",
  },
  showBtn: { background: "var(--panel-3)", color: "var(--ink-2)", border: "1px solid var(--line)", borderRadius: 5, padding: "0 10px", fontSize: 11, fontFamily: "var(--mono)", cursor: "pointer" },
  storageRow: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 },
  storageOpt: {
    display: "flex", alignItems: "flex-start", gap: 8,
    padding: "8px 10px",
    background: "var(--panel-2)", border: "1px solid var(--line-soft)", borderRadius: 6,
    cursor: "pointer",
  },
  storageActive: { borderColor: "var(--accent)", background: "rgba(200, 255, 94, 0.04)" },
  radio: { marginTop: 3 },
  storageTitle: { fontSize: 12.5, fontWeight: 500, marginBottom: 2 },
  storageSub: { fontSize: 11, color: "var(--ink-3)" },
  recBadge: { background: "rgba(200, 255, 94, 0.12)", color: "var(--accent)", padding: "0 5px", borderRadius: 999, fontSize: 9, marginLeft: 4, fontFamily: "var(--mono)", letterSpacing: 0.3 },

  testCheck: { display: "flex", alignItems: "center", gap: 8, fontSize: 12.5, color: "var(--ink-2)", marginBottom: 6 },
  faint: { color: "var(--ink-3)" },
  checks: { background: "var(--panel-2)", border: "1px solid var(--line-soft)", borderRadius: 6, padding: "0 12px" },

  errBox: { marginTop: 10, display: "flex", gap: 10, padding: "10px 12px", background: "rgba(255, 118, 118, 0.08)", border: "1px solid rgba(255, 118, 118, 0.25)", borderRadius: 6 },
  errIcon: { width: 22, height: 22, display: "grid", placeItems: "center", background: "var(--bad)", color: "#0e1014", borderRadius: 999, fontWeight: 700 },
  errTitle: { fontSize: 13, fontWeight: 600, color: "var(--bad)", fontFamily: "var(--mono)" },
  errBody: { fontSize: 11.5, color: "var(--ink-2)", marginTop: 2 },

  footer: { marginTop: 14, display: "flex", alignItems: "center", gap: 8 },
  cancel: { background: "transparent", color: "var(--ink-3)", border: "1px solid var(--line)", padding: "7px 12px", borderRadius: 5, fontSize: 12.5, fontFamily: "inherit", cursor: "pointer" },
  primary: { background: "var(--accent)", color: "var(--accent-ink)", border: 0, padding: "8px 16px", borderRadius: 5, fontSize: 12.5, fontWeight: 600, cursor: "pointer", fontFamily: "inherit" },
  primaryDisabled: { background: "var(--panel-3)", color: "var(--ink-3)", cursor: "not-allowed" },
};

Object.assign(window, { SetupWizard });
